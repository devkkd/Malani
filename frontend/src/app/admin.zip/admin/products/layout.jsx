"use client";
import AdminLayout from '@/components/admin/AdminLayout';

export default function ProductsLayout({ children }) {
  return <AdminLayout>{children}</AdminLayout>;
}
